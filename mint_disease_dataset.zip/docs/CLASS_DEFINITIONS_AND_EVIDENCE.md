# Mint Disease Dataset — Class Definitions and Evidence

## 1. Healthy Mint
**Meaning:** Mint foliage without visible disease symptoms.

This is a control/reference class. Minor natural blemishes are allowed, but obvious disease lesions, powdery growth, pustules, major yellowing, or severe damage should be rejected during manual QC.

## 2. Mint Rust
**Biological disease:** Mint rust, primarily associated with *Puccinia menthae*.

**Supported visual cues:** dusty orange pustules; later yellow/black pustules; yellowing and dead leaf tissue; pustules can be especially visible on leaf undersides.

**Source:** RHS, “Mint rust” — https://www.rhs.org.uk/disease/mint-rust

## 3. Mint Powdery Mildew
**Biological disease:** Powdery mildew of mint; APS lists *Erysiphe* spp. among mint diseases.

**Supported general visual cues:** white-to-gray powdery growth on leaf surfaces; possible yellowing, browning or distortion.

**Important evidence limitation:** the APS page confirms the disease in mint, while the detailed symptom description used for prompt design comes from general UC IPM powdery-mildew guidance. Therefore, the dataset must not claim that every generated image is a verified mint-specific morphology.

**Sources:**
- APS, “Diseases of Mint” — https://www.apsnet.org/edcenter/resources/commonnames/Pages/Mint.aspx
- UC IPM, “Powdery Mildew on Ornamentals” — https://ipm.ucanr.edu/home-and-landscape/powdery-mildew-on-ornamentals/

## 4. Mint Leaf Spots — Combined Visual Class
**This is NOT one biological disease.**

Mint has multiple documented spot diseases, including:
- Septoria leaf spot
- Ramularia leaf spot
- Phoma leaf spot
- Anthracnose / leopard spot

The project intentionally combines visually spot-like lesions into one class for an initial image-classification prototype.

A USDA-linked mint anthracnose document describes small brown spots that enlarge into oval lesions with light-gray centers and reddish-brown borders. This is used only as an evidence-backed visual reference for the anthracnose/leopard-spot-like subset.

**Sources:**
- APS, “Diseases of Mint” — https://www.apsnet.org/edcenter/resources/commonnames/Pages/Mint.aspx
- USDA-linked, “Mint Anthracnose” — https://ageconsearch.umn.edu/record/308893/files/aib212.pdf

### What the Leaf Spots class does NOT mean
A model predicting `mint_leaf_spots` must not be interpreted as diagnosing Septoria, Ramularia, Phoma, or anthracnose specifically. A specialist or additional class-specific dataset would be required for that level of diagnosis.

## 5. Dataset-use rule
All generated images are **synthetic images**. They are suitable for experimentation, prototype training and augmentation research, but they do not replace real field photographs.

A final disease-detection system should be evaluated on an independently collected real-mint test set that was never used to write prompts or tune the model.
