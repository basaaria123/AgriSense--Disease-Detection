# Methodology (for the project report)

**Objective.** Create an AI-generated mint leaf image set (healthy, rust, powdery mildew, combined leaf spots) as a prototype and augmentation resource for image classification.

**Class definition.** Visual definitions were derived from extension, horticultural-society and peer-reviewed sources (docs/CLASS_DEFINITIONS_AND_EVIDENCE.md). The leaf-spot class is a project-defined combined visual class (Septoria-, anthracnose- and Ramularia-type appearances); it is not a single pathogen. Phoma-type appearance was not generated because no symptom description was found.

**Generation.** Candidates were produced with a text-to-image diffusion model (default stabilityai/stable-diffusion-xl-base-1.0 via Hugging Face diffusers; the exact model, library version, GPU, seed, steps, guidance and size are logged per image at run time). Prompts are assembled from fixed pools (plant, shot, camera, lighting, background, severity-specific symptom). Background, lighting and camera pools are identical for all classes to avoid class shortcuts. 225 candidates per class (75 per severity) were planned to allow for rejection; final targets are 50 per severity per disease class and 150 healthy.

**Quality control.** Automatic: file integrity, size, exact (MD5) and near-duplicate (256-bit dHash, optional CLIP) detection, relative low-sharpness flags. Manual (required): mint identity, text/watermark, anatomical plausibility, lesion realism, symptom visibility, mixed-disease and background-dominance checks, exclusion of edge-scorch look-alikes. Decisions and reasons are stored in qc_review.csv and the generation log.

**Splitting.** Accepted originals were split first, stratified by class and severity (seed 42, ~70/15/15). Augmentation was then applied to training originals only (rotation +-10 deg, 88-97 % crop and resize, horizontal flip, brightness/contrast 0.85-1.15, mild blur in ~20 %; 3 copies per image; parameters recorded). Validation and test sets were not augmented. The verification script checks that no augmented file or identical content appears outside train.

**Limitations.** Synthetic images may not reflect real lesion morphology; severity is prompt intent checked visually; performance on the synthetic test split does not establish real-world accuracy. Independent real-photo validation is required.
