# Manual QC Guide — Mint Disease Dataset

Manual review is required. Automatic checks cannot reliably decide whether a generated lesion is biologically plausible.

For each image, mark **PASS** only when all applicable checks are satisfied.

## A. Mint identity
- The plant should clearly look like mint.
- Reject obvious basil, rose, tomato, grapevine, random herb, or ambiguous foliage.
- Reject images where the disease is visible but the plant identity cannot reasonably be established.

## B. Disease visibility
### Mint Rust
Look for orange/rust-colored pustule-like structures, often with yellowing. Underside pustules are acceptable and useful.
Reject if the image mainly shows generic orange/brown discoloration without pustule-like structures.

### Powdery Mildew
Look for a convincing white-to-gray powdery surface growth.
Reject if it looks like frost, paint, dust, water droplets, or a large solid white object.

### Leaf Spots
Look for discrete brown/dark/necrotic leaf lesions or merging spot-like lesions.
This is a combined visual class. Do not require one exact shape.
Reject if the image is only generally yellow, wilted, nutrient-stressed, sunburned, or physically damaged without spot-like lesions.

## C. Image realism
Reject:
- impossible leaf geometry
- duplicated/melted leaves
- strange veins
- plastic-looking lesions
- repeated identical lesions
- impossible stems
- obvious AI artifacts
- text, labels, watermarks or UI elements

## D. Mixed disease / contamination
Reject if two target disease appearances are clearly present together, unless the project later explicitly chooses a multi-label design.

Examples:
- obvious rust pustules + obvious powdery coating
- powdery mildew + large unrelated spot disease
- rust + another clearly distinct disease

## E. Background shortcut
Reject or flag if the background is so dominant that the leaf/disease cannot be inspected.

## F. Severity
Use the generated severity only as a rough visual label:
- **Mild:** limited lesions/coating, much healthy tissue remains
- **Moderate:** obvious disease over a substantial area
- **Severe:** extensive symptoms, merging lesions/coating, substantial tissue damage

Do not treat these as measured percentages.

## G. Important rule
Do not “fix” an uncertain image by guessing. If the disease cannot be confidently judged, mark it for rejection/review rather than passing it.
