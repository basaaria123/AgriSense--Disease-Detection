# Organized Mint Disease Detection Dataset

This dataset contains a structured collection of mint (Mentha) leaf images supporting machine learning for disease classification. It is compiled exclusively using high-quality synthetic images that have successfully passed automated and manual Quality Control (QC) filters.

## Dataset Summary
- **Target Species**: Mint (*Mentha*)
- **Total Images**: 130
- **Image Source**: AI-generated (Synthetic via Stable Diffusion XL)
- **Verification Level**: Fully reviewed & manually verified (100% Pass Decision)

## Class Distribution
- **`mint_rust`**: 34 images
- **`mint_powdery_mildew`**: 34 images
- **`mint_leaf_spots`**: 34 images
- **`healthy_mint`**: 28 images


## Dataset Split Structure
- **`train`**: 120 images
- **`validation`**: 5 images
- **`test`**: 5 images


## Directory Layout
```
mint_disease_dataset/
  ├── train/
  │    ├── healthy_mint/
  │    ├── mint_rust/
  │    ├── mint_powdery_mildew/
  │    └── mint_leaf_spots/
  ├── validation/
  │    ├── [classes]/
  ├── test/
  │    ├── [classes]/
  ├── dataset_metadata.csv
  └── README.md
```

## Dataset Limitations & Research Disclaimer
- These images are AI-generated (synthetic) to simulate realistic symptoms under greenhouse and field settings.
- While visually consistent, these models are recommended to be fine-tuned or scientifically validated with real-world photographs of infected mint leaves before deployment in critical agronomic environments.
